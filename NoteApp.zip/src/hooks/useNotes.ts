import { useState, useEffect, useCallback } from 'react';
import { Note } from '../types/note';
import { getNotes, saveNotes } from '../utils/storage';

export const useNotes = () => {
  const [allNotes, setAllNotes] = useState<Note[]>([]);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  useEffect(() => {
    setAllNotes(getNotes());
  }, []);

  const addNote = useCallback((title: string, content: string) => {
    const newNote: Note = {
      id: Date.now(),
      title: title.trim(),
      content: content.trim(),
      timestamp: new Date().toISOString()
    };
    const updatedNotes = [newNote, ...allNotes];
    saveNotes(updatedNotes);
    setAllNotes(updatedNotes);
  }, [allNotes]);

  const deleteNote = useCallback((id: number) => {
    setDeletingId(id);
    setTimeout(() => {
      const updatedNotes = allNotes.filter(note => note.id !== id);
      saveNotes(updatedNotes);
      setAllNotes(updatedNotes);
      setDeletingId(null);
    }, 400);
  }, [allNotes]);

  const updateNote = useCallback((id: number, title: string, content: string) => {
    const updatedNotes = allNotes.map(note =>
      note.id === id
        ? { ...note, title: title.trim(), content: content.trim() }
        : note
    );
    saveNotes(updatedNotes);
    setAllNotes(updatedNotes);
  }, [allNotes]);

  return {
    allNotes,
    deletingId,
    addNote,
    deleteNote,
    updateNote
  };
};
