import React, { useState, useMemo } from 'react';
import AddNoteForm from './components/AddNoteForm';
import SearchBar from './components/SearchBar';
import NotesList from './components/NotesList';
import { useNotes } from './hooks/useNotes';

const App: React.FC = () => {
  const { allNotes, deletingId, addNote, deleteNote, updateNote } = useNotes();
  const [searchQuery, setSearchQuery] = useState('');
  const [notification, setNotification] = useState('');
  const [error, setError] = useState('');

  const showNotification = (message: string) => {
    setNotification(message);
    setTimeout(() => setNotification(''), 3000);
  };

  const handleAddNote = (title: string, content: string) => {
    if (!title.trim() || !content.trim()) {
      setError('Both title and content are required!');
      setTimeout(() => setError(''), 3000);
      return;
    }
    addNote(title, content);
    setError('');
    showNotification('✨ Note added successfully!');
  };

  const handleDeleteNote = (id: number) => {
    deleteNote(id);
    showNotification('🗑️ Note deleted successfully!');
  };

  const handleEditNote = (id: number, title: string, content: string) => {
    updateNote(id, title, content);
    showNotification('✏️ Note updated successfully!');
  };

  const filteredNotes = useMemo(() => {
    if (!searchQuery.trim()) return allNotes;
    const query = searchQuery.toLowerCase();
    return allNotes.filter(note =>
      note.title.toLowerCase().includes(query) ||
      note.content.toLowerCase().includes(query)
    );
  }, [allNotes, searchQuery]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50 p-4 sm:p-6 overflow-hidden">
      {notification && (
        <div className="fixed top-6 right-6 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-3 rounded-xl shadow-2xl z-50 transform transition-all duration-500 ease-out animate-slide-in-right">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            {notification}
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8 transform transition-all duration-700 ease-out animate-fade-in-down">
          <h1 className="text-4xl sm:text-6xl font-bold bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 bg-clip-text text-transparent mb-3 animate-gradient">
            📝 My Notes
          </h1>
          <p className="text-gray-600 text-sm sm:text-base transition-all duration-500">Capture your thoughts and ideas beautifully</p>
        </div>

        <AddNoteForm onAdd={handleAddNote} error={error} />

        {allNotes.length > 0 && (
          <SearchBar searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
        )}

        <NotesList
          notes={filteredNotes}
          allNotesLength={allNotes.length}
          onEdit={handleEditNote}
          onDelete={handleDeleteNote}
          deletingId={deletingId}
        />
      </div>


    </div>
  );
};

export default App;
