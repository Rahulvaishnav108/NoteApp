import React, { useState, useCallback } from 'react';
import { Trash2, Edit2, Check, X, Clock } from 'lucide-react';
import { Note } from '../types/note';

interface NoteItemProps {
  note: Note;
  onEdit: (id: number, title: string, content: string) => void;
  onDelete: (id: number) => void;
  index: number;
  deletingId: number | null;
}

const NoteItem: React.FC<NoteItemProps> = ({ note, onEdit, onDelete, index, deletingId }) => {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');

  const startEdit = useCallback(() => {
    setEditingId(note.id);
    setEditTitle(note.title);
    setEditContent(note.content);
  }, [note]);

  const cancelEdit = useCallback(() => {
    setEditingId(null);
    setEditTitle('');
    setEditContent('');
  }, []);

  const saveEdit = useCallback(() => {
    if (!editTitle.trim() || !editContent.trim()) {
      return;
    }
    onEdit(note.id, editTitle, editContent);
    setEditingId(null);
  }, [editTitle, editContent, note.id, onEdit]);

  const formatTimestamp = useCallback((timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }, []);

  return (
    <div
      className={`group bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg p-6 border-2 border-gray-100 hover:border-purple-300 hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 hover:rotate-1 ${
        deletingId === note.id ? 'animate-scale-out' : 'animate-slide-up'
      }`}
      style={{
        animationDelay: `${index * 50}ms`,
        animationFillMode: 'both'
      }}
    >
      {editingId === note.id ? (
        <div className="space-y-3 animate-fade-in">
          <input
            type="text"
            value={editTitle}
            onChange={(e) => setEditTitle(e.target.value)}
            className="w-full px-3 py-2 border-2 border-purple-300 rounded-lg focus:border-purple-500 focus:outline-none focus:ring-2 focus:ring-purple-100 transition-all duration-300"
          />
          <textarea
            value={editContent}
            onChange={(e) => setEditContent(e.target.value)}
            rows={3}
            className="w-full px-3 py-2 border-2 border-purple-300 rounded-lg focus:border-purple-500 focus:outline-none focus:ring-2 focus:ring-purple-100 resize-none transition-all duration-300"
          />
          <div className="flex gap-2">
            <button
              onClick={saveEdit}
              className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white py-2 rounded-lg hover:shadow-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-1"
            >
              <Check className="w-4 h-4" />
              Save
            </button>
            <button
              onClick={cancelEdit}
              className="flex-1 bg-gradient-to-r from-gray-500 to-gray-600 text-white py-2 rounded-lg hover:shadow-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-1"
            >
              <X className="w-4 h-4" />
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <>
          <div className="flex justify-between items-start mb-3">
            <h3 className="text-lg sm:text-xl font-bold text-gray-800 flex-1 pr-2 group-hover:text-purple-600 transition-colors duration-300">
              {note.title}
            </h3>
            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-2 group-hover:translate-x-0">
              <button
                onClick={startEdit}
                className="text-blue-600 hover:bg-blue-50 p-2 rounded-lg transition-all duration-300 transform hover:scale-110 hover:rotate-12"
                title="Edit note"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => onDelete(note.id)}
                className="text-red-600 hover:bg-red-50 p-2 rounded-lg transition-all duration-300 transform hover:scale-110 hover:rotate-12"
                title="Delete note"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          <p className="text-gray-600 mb-4 whitespace-pre-wrap break-words leading-relaxed transition-all duration-300">
            {note.content}
          </p>

          <div className="flex items-center gap-1 text-xs text-gray-400 pt-3 border-t border-gray-100 group-hover:border-purple-200 transition-all duration-300">
            <Clock className="w-3 h-3" />
            <span>{formatTimestamp(note.timestamp)}</span>
          </div>
        </>
      )}
    </div>
  );
};

export default NoteItem;
