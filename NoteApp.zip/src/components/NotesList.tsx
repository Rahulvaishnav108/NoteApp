import React from 'react';
import NoteItem from './NoteItem';
import { Note } from '../types/note';

interface NotesListProps {
  notes: Note[];
  allNotesLength: number;
  onEdit: (id: number, title: string, content: string) => void;
  onDelete: (id: number) => void;
  deletingId: number | null;
}

const NotesList: React.FC<NotesListProps> = ({ notes, allNotesLength, onEdit, onDelete, deletingId }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
      {notes.length === 0 && allNotesLength === 0 ? (
        <div className="col-span-full text-center py-20 animate-bounce-slow">
          <div className="text-6xl mb-4">📝</div>
          <p className="text-xl text-gray-400">No notes yet. Create your first note above! ✨</p>
        </div>
      ) : notes.length === 0 ? (
        <div className="col-span-full text-center py-20">
          <div className="text-6xl mb-4">🔍</div>
          <p className="text-xl text-gray-400">No notes found matching your search</p>
        </div>
      ) : (
        notes.map((note, index) => (
          <NoteItem
            key={note.id}
            note={note}
            onEdit={onEdit}
            onDelete={onDelete}
            index={index}
            deletingId={deletingId}
          />
        ))
      )}
    </div>
  );
};

export default NotesList;
