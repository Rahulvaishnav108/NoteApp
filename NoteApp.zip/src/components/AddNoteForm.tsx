import React, { useState, useCallback } from 'react';
import { Plus } from 'lucide-react';

interface AddNoteFormProps {
  onAdd: (title: string, content: string) => void;
  error: string;
}

const AddNoteForm: React.FC<AddNoteFormProps> = ({ onAdd, error }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  const handleAddNote = useCallback(() => {
    if (!title.trim() || !content.trim()) {
      return;
    }

    setIsAdding(true);

    setTimeout(() => {
      onAdd(title, content);
      setTitle('');
      setContent('');
      setIsAdding(false);
    }, 300);
  }, [title, content, onAdd]);

  const handleKeyPress = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleAddNote();
    }
  }, [handleAddNote]);

  return (
    <div className="bg-white/80 backdrop-blur-lg rounded-3xl shadow-2xl p-6 sm:p-8 mb-8 border border-white/50 transform transition-all duration-500 hover:shadow-3xl animate-scale-in">
      <h2 className="text-xl sm:text-2xl font-semibold text-gray-800 mb-6 flex items-center gap-2">
        <div className="p-2 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg">
          <Plus className="w-5 h-5 text-white" />
        </div>
        Create New Note
      </h2>

      <div className="space-y-4">
        <div className="transform transition-all duration-300 hover:scale-[1.01]">
          <input
            type="text"
            placeholder="✨ Note Title..."
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onKeyPress={handleKeyPress}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none focus:ring-4 focus:ring-purple-100 transition-all duration-300 bg-white/50 backdrop-blur"
          />
        </div>

        <div className="transform transition-all duration-300 hover:scale-[1.01]">
          <textarea
            placeholder="📝 Write your note content here... (Press Ctrl+Enter to add)"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onKeyPress={handleKeyPress}
            rows={4}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none focus:ring-4 focus:ring-purple-100 transition-all duration-300 resize-none bg-white/50 backdrop-blur"
          />
        </div>

        {error && (
          <div className="bg-red-50 border-2 border-red-200 text-red-700 px-4 py-3 rounded-xl animate-shake-error transform transition-all duration-300">
            <span className="font-medium">⚠️ {error}</span>
          </div>
        )}

        <button
          onClick={handleAddNote}
          disabled={isAdding}
          className="group w-full bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 text-white py-3 rounded-xl font-semibold hover:shadow-2xl transition-all duration-500 transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-pink-600 via-purple-600 to-blue-600 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
          <Plus className={`w-5 h-5 relative z-10 transition-transform duration-300 ${isAdding ? 'rotate-90' : 'group-hover:rotate-90'}`} />
          <span className="relative z-10">{isAdding ? 'Adding...' : 'Add Note'}</span>
        </button>
      </div>
    </div>
  );
};

export default AddNoteForm;
